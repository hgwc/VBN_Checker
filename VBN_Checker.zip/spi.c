
#include "spi.h"

/**
 * @brief SPI user event handler.
 * @param event
 */
void spi_adc_event_handler(nrf_drv_spi_evt_t const * p_event,
                       void *                    p_context)
{
    spi_adc_xfer_done = true;

	NRF_LOG_INFO("SPI0_Transfer completed.");
    if (m_rx0_buf[0] != 0)
    {
       NRF_LOG_INFO(" SPI0_Received:");
        NRF_LOG_HEXDUMP_INFO(m_rx0_buf, strlen((const char *)m_rx0_buf));
    }
}

void spi_dac_cs0_event_handler(nrf_drv_spi_evt_t const * p_event,
                       void *                    p_context)
{
    spi_dac_cs0_xfer_done = true;

	NRF_LOG_INFO("SPI1_Transfer completed.");
    if (m_rx1_buf[0] != 0)
    {
       NRF_LOG_INFO(" SPI1_Received:");
        NRF_LOG_HEXDUMP_INFO(m_rx1_buf, strlen((const char *)m_rx1_buf));
    }
}

void spi_dac_cs1_event_handler(nrf_drv_spi_evt_t const * p_event,
                       void *                    p_context)
{
    spi_dac_cs1_xfer_done = true;

	NRF_LOG_INFO("SPI1_Transfer completed.");
    if (m_rx1_buf[0] != 0)
    {
       NRF_LOG_INFO(" SPI2_Received:");
        NRF_LOG_HEXDUMP_INFO(m_rx2_buf, strlen((const char *)m_rx1_buf));
    }
}

void spi_init(void)
{
    nrf_drv_spi_config_t spi_adc_config = NRF_DRV_SPI_DEFAULT_CONFIG;
    spi_adc_config.ss_pin   = SPI0_ADC_CS;
    spi_adc_config.miso_pin = SPI0_ADC_DIN;
    spi_adc_config.mosi_pin = SPI0_ADC_DOUT;
    spi_adc_config.sck_pin  = SPI0_ADC_SCLK;
    APP_ERROR_CHECK(nrf_drv_spi_init(&spi_adc, &spi_adc_config, spi_adc_event_handler, NULL));
	
//����    nrf_drv_spi_config_t spi_dac_cs0_config = NRF_DRV_SPI_DEFAULT_CONFIG;
//   spi_dac_cs0_config.ss_pin   = DAC_CS0;
//���� /������� ����	   spi_dac_cs0_config.miso_pin = SPI1_MISO_PIN;
// ����   spi_dac_cs0_config.mosi_pin = DAC_SDI;
// ����   spi_dac_cs0_config.sck_pin  = DAC_SCLK;
// ����   APP_ERROR_CHECK(nrf_drv_spi_init(&spi_dac_cs0, &spi_dac_cs0_config, spi_dac_cs0_event_handler, NULL));	
//
// ����   nrf_drv_spi_config_t spi_dac_cs1_config = NRF_DRV_SPI_DEFAULT_CONFIG;
//����    spi_dac_cs0_config.ss_pin   = DAC_CS1;
///������� ����	   spi_dac_cs0_config.miso_pin = SPI1_MISO_PIN;
//����    spi_dac_cs0_config.mosi_pin = DAC_SDI;
// ����   spi_dac_cs0_config.sck_pin  = DAC_SCLK;
// ����   APP_ERROR_CHECK(nrf_drv_spi_init(&spi_dac_cs0, &spi_dac_cs1_config, spi_dac_cs1_event_handler, NULL));	
}

