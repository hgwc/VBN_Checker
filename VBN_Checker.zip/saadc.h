#include "nrf_log.h"
#include "nrf_drv_saadc.h"
#include "nrf_drv_ppi.h"
#include "nrf_drv_timer.h"
#include "ble_nus.h"

//#include "nrf_log_ctrl.h"
//#include "nrf_log_default_backends.h"

#define SAMPLES_IN_BUFFER         8		//���� 4
static const nrf_drv_timer_t   m_timer = NRF_DRV_TIMER_INSTANCE(3);
static nrf_saadc_value_t       m_buffer_pool[2][SAMPLES_IN_BUFFER];
static nrf_ppi_channel_t       m_ppi_channel;
static uint32_t                m_adc_evt_counter;

void saadc_init(void);
void saadc_sampling_event_init(void);
void saadc_sampling_event_enable(void);
