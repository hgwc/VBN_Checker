int main(void)
{
    uint32_t err_code;
//	bool     erase_bonds;

    // Initialize.
    err_code = app_timer_init();
    APP_ERROR_CHECK(err_code);

    uart_init();
    log_init();

#if 0
//180227
	buttons_leds_init(&erase_bonds);
#else
	bsp_board_leds_init();
#endif
    ble_stack_init();
    gap_params_init();
    gatt_init();
    services_init();
    advertising_init();
    conn_params_init();

//180223 SPI-S
    APP_ERROR_CHECK(NRF_LOG_INIT(NULL));
    NRF_LOG_DEFAULT_BACKENDS_INIT();
    
    NRF_LOG_INFO("SPI example.");

    nrf_drv_spi_config_t spi_config = NRF_DRV_SPI_DEFAULT_CONFIG;
    spi_config.ss_pin   = SPI_SS_PIN;
    spi_config.miso_pin = SPI_MISO_PIN;
    spi_config.mosi_pin = SPI_MOSI_PIN;
    spi_config.sck_pin  = SPI_SCK_PIN;
    APP_ERROR_CHECK(nrf_drv_spi_init(&spi, &spi_config, spi_event_handler, NULL));
//180223 SPI-E
	
    printf("\r\nUART Start!\r\n");
    NRF_LOG_INFO("UART Start!");
    err_code = ble_advertising_start(&m_advertising, BLE_ADV_MODE_FAST);
    APP_ERROR_CHECK(err_code);

    while (1)
    {
        // Reset rx buffer and transfer done flag
        memset(m_rx_buf, 0, m_length);
        spi_xfer_done = false;

        APP_ERROR_CHECK(nrf_drv_spi_transfer(&spi, m_tx_buf, m_length, m_rx_buf, m_length));

		nrf_delay_ms(200);

        while (!spi_xfer_done)
        {
            __WFE();
        }

        NRF_LOG_FLUSH();

		bsp_board_led_invert(BSP_BOARD_LED_0);
		bsp_board_led_invert(BSP_BOARD_LED_1);
		bsp_board_led_invert(BSP_BOARD_LED_2);		
        bsp_board_led_invert(BSP_BOARD_LED_3);		
        nrf_delay_ms(200);
    }
//180223 SPI-E	

#if 0
    // Enter main loop.
    for (;;)
    {
        UNUSED_RETURN_VALUE(NRF_LOG_PROCESS());
    printf("\r\nUART Start!\r\n");
    NRF_LOG_INFO("UART Start!");		
        power_manage();
    }
#endif	
}